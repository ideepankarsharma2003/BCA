public class _01_Strings{
    public static void main(String[] args) {
        String s1="Tushar";
        String s2="Jeena";
        String s3=s1.concat(s2);
        System.out.println(s3);
        int length1=s1.length();
        System.out.println("length of s1 ="+length1);
        int length2=s2.length();
        System.out.println("length of s2 ="+length2);
    }
}