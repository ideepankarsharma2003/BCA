# Mini-Project-3rd-Semester

An Android Application for all your basic needs.

**This project is based on ‘Multi-Utility App For serving Basic life-neccesity ’.**


With this app users can make their life easier. For travelling  - This app Can book Cab for you,
If you are Hungry -You can go with Ordering Food,-
Now you want a place to sleep – Book Hotels 
After that you need to wear something Here we have solution for That TOO- Shop Clothes online , Grocceries.
This means Now you can do whatever your basic life needs in one **single APP**.



![Screenshot (84)](https://user-images.githubusercontent.com/91521935/155832192-c191fc11-6a51-43e2-9880-e2b8dc79ba0b.png)



![Screenshot (85)](https://user-images.githubusercontent.com/91521935/155832194-89fb2227-5acc-4f2b-bc6c-66525d9b7d9e.png)
